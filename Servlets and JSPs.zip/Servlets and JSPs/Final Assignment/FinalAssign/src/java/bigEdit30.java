/**
 * This program is the GUI for the bifEdit software. It has been 
 * improved so that it can make a connection to the servlet to perform
 * various functions.
 * 
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.BadLocationException;

import SimpleOffice.FileServerClient;
import SimpleOffice.WordProcessor;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author jamest
 * This is the main graphical user interface that connects
 * to the file server.
 * 
 */
class myMenuItem extends JMenuItem {
	public myMenuItem(String s) {
		super(s);
		setEnabled(false);
		// setBackground(Color.orange);
	}
}

/*
* This is the main class
*/
public class bigEdit30 extends JFrame implements WordProcessor, FileServerClient, ActionListener {
	private int currentState = FILE_IDLE_STATE;
	private int lastState = FILE_IDLE_STATE;
	private int nextState = FILE_IDLE_STATE;

	private static final int FILE_IDLE_STATE = 0;
	private static final int FILE_NEW_STATE = 1;
	private static final int FILE_OPEN_STATE = 2;
	private static final int FILE_SAVE_STATE = 3;
	private static final int FILE_SAVEAS_STATE = 4;
	private static final int FILE_CLOSE_STATE = 5;
	private static final int SERVER_CONNECT_STATE = 6;

	private JPanel textp;
	private JMenuBar mb;

	private myMenuItem filemi1, filemi2, filemi3, filemi4,editmi1, editmi2, editmi3, editmi4, editmi5, formatmi1, formatmi2, formatmi3, formatmi4, formatmi5,
	formatmi6, formatmi7,windowmi1, windowmi2, windowmi3,helpmi1, helpmi2, helpmi3;
	private JMenu windowmenu, filemenu, editmenu, formatmenu, helpmenu;
	private JTextArea ta;
	private JPanel namep;
	private JLabel namelbl;
	private myMenuItem filemi5;
	private myMenuItem filemi6, filemi7;
	private File selectedFile, saveFile;
	private String currentOpenFname;
	private String currentFilePath;
	private boolean fileOpenFlag = false;
	private boolean debugflag = true;
	private String newDocumentName = "Untitled.txt";
	private Object bigEditState;
        
        private URL url;
        public static final Logger log = Logger.getLogger(bigEdit30.class.getName());

	public bigEdit30() {
		setTitle("bigEdit v3.0");
		setupConnectPropertySheet();
		setupMenu();
		setVisible(true);
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
	}// end constructor

	private void setupConnectPropertySheet() {
		// TODO Auto-generated method stub
            
         
        log.log(Level.INFO,"Setup has completed"); //Log the event
       
		
	}

	public void setupMenu() {
		// TOODOO Initialize Text editing area

		textp = new JPanel();
		namep = new JPanel();
		// namep.setBackground(Color.gray);
		namelbl = new JLabel("", JLabel.CENTER);
		namep.add(namelbl);
		add(namep, BorderLayout.NORTH);

		Dimension d = new Dimension(600, 800);
		textp.setPreferredSize(d);
		// textp.setBackground(Color.gray);
		ta = new JTextArea();
		ta.setRows(40);
		ta.setColumns(40);
		textp.add(ta);
		ta.setLineWrap(true);
		ta.setWrapStyleWord(true);
		// ta.setBackground(Color.lightGray);
		add(textp, BorderLayout.SOUTH);

		// TOODOO Initialize Menubar
		mb = new JMenuBar();
		// mb.setBackground(Color.lightGray);

		// File,Edit,Format,Window,Help Menus
		// TOODOO Setup File Menu
		filemenu = new JMenu("File");
		// filemenu.setBackground(Color.red);

		filemi1 = new myMenuItem("New");
		filemi2 = new myMenuItem("Open...");
		filemi3 = new myMenuItem("Close");
		filemi4 = new myMenuItem("Save");
		filemi5 = new myMenuItem("Save As...");
		filemi6 = new myMenuItem("Quit");
		filemi7 = new myMenuItem("Connect");

		filemi1.setActionCommand("New");
		filemi1.addActionListener(this);
		filemi2.setActionCommand("Open");
		filemi2.addActionListener(this);
		filemi1.setEnabled(true);
		filemi2.setEnabled(true);

		filemi3.setActionCommand("Close");
		filemi3.addActionListener(this);
		filemi4.setActionCommand("Save");
		filemi4.addActionListener(this);
		filemi5.setActionCommand("Save As...");
		filemi5.addActionListener(this);

		// filemi3.setEnabled(true); // Enable close
		// filemi4.setEnabled(true); // Enable Save
		// filemi5.setEnabled(true); // Enable SaveAs

		filemi6.setActionCommand("Quit");
		filemi6.addActionListener(this);
		filemi6.setEnabled(true); // Enable Quit.

		filemi7.setActionCommand("Connect");
		filemi7.addActionListener(this);
		filemi7.setEnabled(true); // Enable Quit.
		
		// TOODOO build File menu
		filemenu.add(filemi7); // add Connect
		filemenu.add(filemi1);
		filemenu.add(filemi2);
		// filemenu.addSeparator();
		filemenu.add(filemi3);
		filemenu.add(filemi4);
		// filemenu.addSeparator();
		filemenu.add(filemi5);
		filemenu.add(filemi6);
		mb.add(filemenu);

		// TOODOO Setup Edit Menu - Undo,Redo,Cut.Copy,Paste
		editmenu = new JMenu("Edit");
		// editmenu.setBackground(Color.orange);
		editmi1 = new myMenuItem("Undo");
		editmi2 = new myMenuItem("Redo");
		editmi3 = new myMenuItem("Cut");
		editmi4 = new myMenuItem("Copy");
		editmi5 = new myMenuItem("Paste");
		editmenu.add(editmi1);
		editmenu.add(editmi2);
		editmenu.add(editmi3);
		editmenu.add(editmi4);
		editmenu.add(editmi5);
		// editmenu.setEnabled(false);
		mb.add(editmenu);

		// TOODOO Setup Format Menu - Fonts, Bold, Italic,Underline, Actual
		// Size,
		// Zoom in, Zoom Out
		formatmenu = new JMenu("Format");
		// formatmenu.setBackground(Color.green);
		formatmi1 = new myMenuItem("Fonts");
		formatmi2 = new myMenuItem("Bold");
		formatmi3 = new myMenuItem("Italic");
		formatmi4 = new myMenuItem("Underline");
		formatmi5 = new myMenuItem("Actual Size");
		formatmi6 = new myMenuItem("Zoom In");
		formatmi7 = new myMenuItem("Zoom Out");
		formatmenu.add(formatmi1);
		formatmenu.add(formatmi2);
		formatmenu.add(formatmi3);
		formatmenu.add(formatmi4);
		formatmenu.add(formatmi5);
		formatmenu.add(formatmi6);
		formatmenu.add(formatmi7);
		// formatmenu.setEnabled(false);
		mb.add(formatmenu);

		// TOODOO Setup Window Menu - Minimize, Bring All to Front, Show Named
		// Window
		windowmenu = new JMenu("Window");
		// windowmenu.setBackground(Color.gray);
		windowmi1 = new myMenuItem("Minimize");
		windowmi2 = new myMenuItem("Bring All to Front");
		windowmi3 = new myMenuItem("Show Named window");
		windowmenu.add(windowmi1);
		windowmenu.add(windowmi2);
		windowmenu.add(windowmi3);
		// windowmenu.setEnabled(false);
		mb.add(windowmenu);

		// TOODOO Setup Help Menu - Welcome Contents, Search
		helpmenu = new JMenu("Help");
		// helpmenu.setBackground(Color.blue);
		helpmi1 = new myMenuItem("Welcome");
		helpmi2 = new myMenuItem("Contents");
		helpmi3 = new myMenuItem("Search");
		helpmenu.add(helpmi1);
		helpmenu.add(helpmi2);
		helpmenu.add(helpmi3);
		// helpmenu.setEnabled(false);
		mb.add(helpmenu);

		// TOODOO Set the menubar
		setJMenuBar(mb);
	} // end setupMenu

	@Override
	public void actionPerformed(ActionEvent e) {
		if ((e.getActionCommand()).equals("New"))
			newDocument(e.getSource());
		else if ((e.getActionCommand()).equals("Open"))
			openDocument(e.getSource());
		else if ((e.getActionCommand()).equals("Close"))
			closeDocument(e.getSource());
		else if ((e.getActionCommand()).equals("Save"))
			saveDocument(e.getSource());
		else if ((e.getActionCommand()).equals("Save As..."))
			saveAsDocument(e.getSource());
		else if ((e.getActionCommand()).equals("Quit"))
			quitApp(e.getSource());
		else if ((e.getActionCommand()).equals("Connect"))
			connectToServer(e.getSource());
	}

        /*
         * THis method establishes a connection to the file server and prints out
         * the error if any problems occur
        */
	private void connectToServer(Object source) {
		// TODO Auto-generated method stub
            try{
                URL url = new URL("http://localhost:8080/FinalAssign/FileServerServlet");
                System.out.println("Connected");
                log.log(Level.INFO,"Connected");
                
            }catch(MalformedURLException ex){
                ex.printStackTrace();
                System.out.println("There was a problem with the URL link");
            }
		System.out.println("Got a " + ((myMenuItem) source).getActionCommand());

	}

	private void quitApp(Object source) {
		// TODO Auto-generated method stub
		System.out.println("Got a " + ((myMenuItem) source).getActionCommand());
		WindowEvent wev = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
		Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(wev);
                log.log(Level.INFO,"Quit App");
                
	}

	public void saveAsDocument(Object source) {
		// Affairs of state
		currentState(FILE_SAVEAS_STATE);
		debug("\nSaveAs:current state: " + printState(currentState()));
		debug("SaveAs:last state: " + printState(getLastState()));

		// TODO Auto-generated method stub
		System.out.println("Got a " + ((myMenuItem) source).getActionCommand());
		JFileChooser fileChooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"Text (.txt) Files", "txt");
		fileChooser.setFileFilter(filter);
		int status = fileChooser.showSaveDialog(this);
		if (status == JFileChooser.APPROVE_OPTION) {
			setFileMenuState(true);
			selectedFile = fileChooser.getSelectedFile();

			try {
				String fileName = selectedFile.getCanonicalPath();
				if (!fileName.endsWith(".txt")) {
					selectedFile = new File(fileName + ".txt");
				}
				currentOpenFname = selectedFile.getName();
				Path p = Paths.get(fileName);
				currentFilePath = (p.getParent()).toString();
				debug("SaveAs: current open Filename is: " + currentOpenFname);
				debug("SaveAs: current open Filepath is: " + currentFilePath);

				namelbl.setText(currentOpenFname);
				String text = ta.getText();
				int totalLines = ta.getLineCount();
				BufferedWriter out = new BufferedWriter(new FileWriter(
						selectedFile));
				for (int i = 0; i < totalLines; i++) {
					int start = ta.getLineStartOffset(i);
					int end = ta.getLineEndOffset(i);
					String line = text.substring(start, end);
					StringBuffer sb = new StringBuffer(line);
					// sb.append("\n");
					out.write(sb.toString());
					debug(false);
					debug("SaveAs: wrote a line " + sb.toString());
					debug(true);
				}
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (BadLocationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (status != JFileChooser.APPROVE_OPTION) {
			currentState(getLastState());
		}
                log.log(Level.INFO,"Save As...");
	}

	public void saveDocument(Object source) {
		// Affairs of state
		currentState(FILE_SAVE_STATE);
		debug("\nSave:current state: " + printState(currentState()));
		debug("Save:last state: " + printState(getLastState()));

		// TODO Auto-generated method stub
		debug(true);
		debug("Got a " + ((myMenuItem) source).getActionCommand());
		debug("Save:start:before File call:currentOpenFname = "
				+ currentOpenFname);

		saveFile = new File(currentFilePath, currentOpenFname);

		// currentOpenFname = saveFile.getName();
		debug("Save: saveFile abs path is: " + saveFile.getAbsolutePath());
		// debug("Save: saveFile path is: " + saveFile.getPath());

		// Test filename for existence
		if (saveFile.exists() == false) {
			try {
				debug("Save: file named: " + currentOpenFname
						+ " does not exist - create it");
				saveFile.createNewFile();
			} catch (IOException ioe) {
				// TODO Auto-generated catch block
				ioe.printStackTrace();
				quitApp(source);
			} // end catch
		}
		// the file does exist
		debug("Save: file named: " + currentOpenFname
				+ " was previously created");
		try {
			String text = ta.getText();
			int totalLines = ta.getLineCount();
			BufferedWriter out = new BufferedWriter(new FileWriter(saveFile));

			for (int i = 0; i < totalLines; i++) {
				int start = ta.getLineStartOffset(i);
				int end = ta.getLineEndOffset(i);
				String line = text.substring(start, end);
				StringBuffer sb = new StringBuffer(line);
				// sb.append("\n");
				out.write(sb.toString());
				debug(false);
				debug("Save: wrote a line " + sb.toString());
				debug(true);
			}
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
                log.log(Level.INFO,"Save");
	}

	public void closeDocument(Object source) {
		// Affairs of state
		currentState(FILE_CLOSE_STATE);
		debug("Close:current state: " + printState(currentState()));
		debug("Close:last state: " + printState(getLastState()));

		// TODO Auto-generated method stub
		debug(true, "Got a " + ((myMenuItem) source).getActionCommand());
		currentOpenFname = "";
		namelbl.setText("");
		ta.setText("");
		pack();
		setFileMenuState(false);
		currentState(FILE_IDLE_STATE);
		currentFilePath = null;
		currentOpenFname = null;
                log.log(Level.INFO,"Close");
	} // end class

	public void openDocument(Object o) {
		// Affairs of state
		currentState(FILE_OPEN_STATE);
		debug("Open:current state: " + printState(currentState()));
		debug("Open:last state: " + printState(getLastState()));

		BufferedReader in = null;
		// TOODOO Show the file picker
		JFileChooser fp = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"Text (.txt) Files", "txt");

		fp.setFileFilter(filter);
		int returnVal = fp.showOpenDialog(this);
		if (returnVal == JFileChooser.APPROVE_OPTION) {

			currentOpenFname = fp.getSelectedFile().getName();
			// currentOpenFname = selectedFile.getName();
			Path p = Paths.get(fp.getSelectedFile().getAbsolutePath());
			currentFilePath = (p.getParent()).toString();
			try {
				namelbl.setText(currentOpenFname);
				debug("open:currentopenfname: " + currentOpenFname);

				in = new BufferedReader(new FileReader(fp.getSelectedFile()));
				String str;
				ta.setText("");
				while ((str = in.readLine()) != null) {
					ta.append(str + "\n");
				}
			} catch (IOException e) {
			} finally {
				try {
					in.close();
				} catch (Exception ex) {
				}
			}// end finally
			setFileMenuState(true);
			pack();
		}// end if approve
		else if (returnVal != JFileChooser.APPROVE_OPTION) {
			currentState(getLastState());
		}
                log.log(Level.INFO,"Open");
	}// end method

	public void newDocument(Object o) {
		// Affairs of state
		currentState(FILE_NEW_STATE);
		debug("New:current state: " + printState(currentState()));
		debug("New:last state: " + printState(getLastState()));

		// TOODOO Show the New file create dialog box
		// TOODOO Create a new open document named 'Untitled'
		String msg = "Creating document: " + newDocumentName;
		JOptionPane.showMessageDialog(this, msg, "New Document",
				JOptionPane.PLAIN_MESSAGE);
		currentOpenFname = newDocumentName;
		setFileMenuState(true);
		filemi4.setEnabled(false); // disable Save
		namelbl.setText(currentOpenFname);
		ta.setText("");
                log.log(Level.INFO,"Open");
		pack();

	}

	private void setFileMenuState(boolean b) {
		// TODO Auto-generated method stub
		bigEditState = bigEdit30.FILE_OPEN_STATE;
		if (b == true) {
			fileOpenFlag = b;
			filemi3.setEnabled(b); // Enable close
			filemi4.setEnabled(b); // Enable Save
			filemi5.setEnabled(b); // Enable SaveAs;
		} else if (b == false) {
			fileOpenFlag = b;
			filemi3.setEnabled(b); // disable close
			filemi4.setEnabled(b); // disable Save
			filemi5.setEnabled(b); // disable SaveAs;
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new bigEdit30();
	}

	void debug(String s) {
		if (debugflag == true)
			System.err.println(s);
	}

	void debug(boolean b) {
		debugflag = b;
	}

	void debug(boolean onetimeflag, String s) {
		/**
		 * if onetimeFlag is true Allows you to override debugFlag and issue a
		 * debug message if onetimeFlag is false Sets debugFlag to true and
		 * prints message
		 */
		if (onetimeflag == true) { // print ignore debugflag
			System.err.println(s);
		} else if (onetimeflag == false) { // print AND turn on debug flag
			debug(true);
			System.err.println(s);

		}
	}

	public int currentState() {
		return currentState;
	}

	public void currentState(int currentState) {
		setLastState(this.currentState);
		this.currentState = currentState;
	}

	public int getLastState() {
		return lastState;
	}

	public void setLastState(int lastState) {
		this.lastState = lastState;
	}

	String printState(int i) {
		switch (i) {

		case FILE_IDLE_STATE:
			return ("State: IDLE");
			// break;
		case FILE_NEW_STATE:
			return ("State: NEW");
			// break;
		case FILE_OPEN_STATE:
			return ("State: OPEN");
			// break;
		case FILE_SAVE_STATE:
			return ("State: SAVE");
			// break;
		case FILE_SAVEAS_STATE:
			return ("State: SAVEAS");
			// break;
		case FILE_CLOSE_STATE:
			return ("State: CLOSE");
		case SERVER_CONNECT_STATE:
			return ("State: CONNECT");
			// break;
		default:
			return ("State: UNDEFINED");
			// break;
		}

	}
Thread t;
        /**
         * This is where the connection is made to the servlet.
         * @throws IOException 
         */
	@Override
	public void connectToServer() throws IOException {
		// TODO Auto-generated method stub
            log.log(Level.INFO, "Connected to server");
            String line = "Connected to server";
            try{
                t = new Thread();
                t.setName(url.toString());
                 url = new URL("http://localhost:8080/FinalAssign/FileServerServlet");
                 
                 BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                 line = in.readLine();
                 
                 System.out.println(line);
                 in.close();
            
            }catch(Exception e){
                e.printStackTrace();
            }
           
          
		
	}

        /**
         * This method is where the connection is disconnected from the server
         */
	@Override
	public void disconnectFromServer() {
            log.log(Level.INFO, "Disconnected from the server");
            String line = "disconnected from server";
		// TODO Auto-generated method stub
            t.setName("");
            
            
		
	}

	@Override
	public String[] getDirectoryListing(String dirname) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void openFSDocument(String fname) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void closeFSDocument() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String[] readFSDocument() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void writeFSDocument(String[] fileBuffer) {
		// TODO Auto-generated method stub
		
	}
        
        @Override
        public void shutdown(){
            
        }

    @Override
    public void startup() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void listDirectory(String dirName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void openFile(String fileName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void closeFile() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void readFile() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void writeFile() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

} // end class
