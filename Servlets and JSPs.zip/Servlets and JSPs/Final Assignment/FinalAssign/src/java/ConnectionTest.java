/**
 * This is the connection test class that connects to the file
 * server and gets the code to ensure the connection is valid
 */

/**
 *
 * @author ashishpatel
 */
import SimpleOffice.FileServerClient;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConnectionTest implements FileServerClient {
    
    
    
    public static void main(String[] args) throws IOException{
        
            ConnectionTest ct = new ConnectionTest();
            ct.connectToServer();
        
    }

    
    /**
     * This method establishes a test connection to the file
     * server and gets the content of the servlet printed out
     * 
     * @throws IOException 
     */
    
    public void connectToServer() throws IOException {
        try{
            URL url = new URL("http://localhost:8080/FinalAssign/FileServerServlet");
            
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
            out.write("username=javaworld\r\n");
            out.flush();
            out.close();
            
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            
            String response;
            
            while((response = in.readLine()) != null){
                System.out.println(response);
            }
            
            in.close();
            
        }catch(MalformedURLException ex){
            ex.printStackTrace();
            System.out.println("There is a problem with the URL of the connection");
            
        }catch(IOException e){
            e.printStackTrace();
            System.out.println("There is a major error that has occurred");
        }

    }

    public void disconnectFromServer() {

    }

    public String[] getDirectoryListing(String dirname) {
        return null;

    }

    public void openFSDocument(String fname) {

    }

    public void closeFSDocument() {

    }

    public String[] readFSDocument() {
        return null;

    }

    public void writeFSDocument(String[] fileBuffer) {

    }

}
