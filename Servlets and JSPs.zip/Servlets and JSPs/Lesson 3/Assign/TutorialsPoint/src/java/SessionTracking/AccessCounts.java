/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SessionTracking;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ashishpatel
 */
@WebServlet(name = "AccessCounts", urlPatterns = {"/AccessCounts"})
public class AccessCounts extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        String title = "Session Tracking Example";
        try (PrintWriter out = response.getWriter()) {
            HttpSession session = request.getSession();
            String heading;

            String sessionID = session.getId();
            String fName = (String) session.getAttribute("first_name");
            String lName = (String) session.getAttribute("last_name");
            
            Integer accessCount = (Integer) session.getAttribute("accessCount");

            if (accessCount == null) {
                accessCount = new Integer(0);
                heading = "Welcome Aboard " + fName + " " + lName;
            } else {
                heading = "Welcome Back " + fName + " " + lName;
                accessCount = new Integer(accessCount.intValue() + 1);
            }
            session.setAttribute("accessCount", accessCount);

            out.println("<HTML>\n"
                    + "<BODY BGCOLOR=\"#FDF5E6\">\n"
                    + "<H1 ALIGN=\"CENTER\">" + title
                    + "</H1>\n" + heading
                    + "\n" + session.getId()
                    + "</BODY></HTML>");
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html>\n"
                + "<head><title>\n" + "Correct Language"
                + "</title></head>\n"
                + "<body><h1>" + "Java is the correct language"
                + "</h1></body>\n"
                + "<html>\n");

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
