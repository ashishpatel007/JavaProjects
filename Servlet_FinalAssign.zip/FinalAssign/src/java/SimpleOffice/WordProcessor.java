/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SimpleOffice;

import java.io.IOException;

/**
 *
 * @author ashishpatel
 */
public interface WordProcessor {

    void startup();

    void listDirectory(String dirName);

    void openFile(String fileName);

    void closeFile();

    void readFile();

    void writeFile();

    void shutdown();

}
