/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SimpleOffice;

import java.io.IOException;

/**
 *
 * @author ashishpatel
 */
public interface FileServerClient {

    void connectToServer() throws IOException;

    void disconnectFromServer();

    String[] getDirectoryListing(String dirname);

    void openFSDocument(String fname);

    void closeFSDocument();

    String[] readFSDocument();

    void writeFSDocument(String[] fileBuffer);

}
