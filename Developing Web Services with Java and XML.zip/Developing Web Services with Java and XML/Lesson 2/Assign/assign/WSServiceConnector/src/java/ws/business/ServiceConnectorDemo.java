/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws.business;

import java.io.File;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/**
 *
 * @author ashishpatel
 */
public class ServiceConnectorDemo {

    public static void main(String[] args) {
        try {
            File inputFile = new File("input.txt");
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            PurchaseSummaryService purchaseSummaryService = new PurchaseSummaryService();
            saxParser.parse("purchases.xml", purchaseSummaryService);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
