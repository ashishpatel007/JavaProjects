/*
 * Created on Mar 16, 2006
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package hello;

import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author jlarstone
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class HelloXMLServlet extends HttpServlet {

	private String [] xml = {
		"<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>",
		"<hello>",
		"  <who>",		"    <name>Jeff Larstone</name>",		"    <title>Instructor</title>",
		"    <work>Skilltop Technologies</work>",
		"  </who>",		"  <text>This is a hello document</text>",		"</hello>",
		"\n",
	};
	/**
	 * 
	 */
	public HelloXMLServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1)
		throws ServletException, IOException {
		PrintWriter writer = arg1.getWriter();
		for ( int i = 0, j = xml.length; i < j; i++ )
			writer.println(xml[i]);
	}

}
